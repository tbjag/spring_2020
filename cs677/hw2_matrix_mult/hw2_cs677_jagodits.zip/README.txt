Compilation example:
nvcc -I . matrixmul.cu file_io.cpp matrixmul_gold.cpp

Colab: 

Crashes can cause the drive to dismount. 

Force-stopping a cell can cause the drive to dismount. 

Remounting by itself will appear as if it resets the mount but will not function, use the force_remount option. 

When in doubt just restart the instance, saves a lot of headaches and a lot of time.

If you plan to run many times without error, or for an extended period of time copy project files off the drive mount.
